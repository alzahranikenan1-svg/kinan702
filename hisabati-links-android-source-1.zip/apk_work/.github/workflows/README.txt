GitHub Actions workflow builds android/app/build/outputs/apk/debug/app-debug.apk and uploads it as an artifact.
